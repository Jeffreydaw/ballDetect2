# -*- coding: utf-8 -*-
"""
Created on Wed Jul 27 21:38:48 2016

@author: Jeffrey
"""


counter = range(len(array)-1)
for i in counter
    circleList[i]
end
    